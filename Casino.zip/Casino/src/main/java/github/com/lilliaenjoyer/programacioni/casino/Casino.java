/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package github.com.lilliaenjoyer.programacioni.casino;

/**
 */
public class Casino {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new InterfazGrafica().setVisible(true));
    }
}

