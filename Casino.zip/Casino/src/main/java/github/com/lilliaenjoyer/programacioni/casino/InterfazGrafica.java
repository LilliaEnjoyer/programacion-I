/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.casino;

import java.util.ArrayList;
import java.util.List;

/**
 */
public class InterfazGrafica extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(InterfazGrafica.class.getName());
    private final List<Jugador> listaJugadores = new ArrayList<>();

    public InterfazGrafica() {
        initComponents();

        jLabel7.setVisible(false);
        campoNumero.setVisible(false);
        jLabelJugadorActivo.setText("Jugador:");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Usuario = new javax.swing.JPanel();
        campoNombre = new javax.swing.JTextField();
        campoSaldo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        crearUsuario = new javax.swing.JToggleButton();
        jPanel2 = new javax.swing.JPanel();
        selectorJuego = new javax.swing.JComboBox<>();
        selectorRuleta = new javax.swing.JComboBox<>();
        campoApuesta = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jugar = new javax.swing.JButton();
        estadisticas = new javax.swing.JToggleButton();
        campoNumero = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabelJugadorActivo = new javax.swing.JLabel();
        selectorJugador = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultadosTxt = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        campoSaldo.addActionListener(this::campoSaldoActionPerformed);

        jLabel1.setText("Nombre");
        jLabel2.setText("Saldo");
        jLabel3.setText("Crear usuario");

        crearUsuario.setText("Crear");
        crearUsuario.addActionListener(this::crearUsuarioActionPerformed);

        javax.swing.GroupLayout UsuarioLayout = new javax.swing.GroupLayout(Usuario);
        Usuario.setLayout(UsuarioLayout);
        UsuarioLayout.setHorizontalGroup(
            UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuarioLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(campoSaldo, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                    .addComponent(campoNombre))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(175, 175, 175))
            .addGroup(UsuarioLayout.createSequentialGroup()
                .addGap(184, 184, 184)
                .addComponent(crearUsuario)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        UsuarioLayout.setVerticalGroup(
            UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UsuarioLayout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(UsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(crearUsuario)
                .addContainerGap())
        );

        selectorJuego.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ruleta", "Tragaperras", "Dado" }));
        selectorJuego.addActionListener(this::selectorJuegoActionPerformed);

        selectorRuleta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Par", "Impar", "Numero" }));

        jLabel4.setText("Juego:");
        jLabel5.setText("Apuesta:");
        jLabel6.setText("Tipo de Ruleta");

        jugar.setText("Jugar");
        jugar.addActionListener(this::jugarActionPerformed);

        estadisticas.setText("Estadisticas");
        estadisticas.addActionListener(this::estadisticasActionPerformed);

        jLabel7.setText("Numero");
        jLabelJugadorActivo.setText("Jugador:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jugar)
                .addGap(77, 77, 77)
                .addComponent(estadisticas)
                .addContainerGap(90, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelJugadorActivo)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(selectorJugador, 0, 142, Short.MAX_VALUE)
                    .addComponent(campoNumero)
                    .addComponent(campoApuesta, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(selectorJuego, javax.swing.GroupLayout.Alignment.TRAILING, 0, 142, Short.MAX_VALUE)
                    .addComponent(selectorRuleta, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectorJugador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelJugadorActivo))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectorJuego, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoApuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectorRuleta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(campoNumero, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(estadisticas))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jugar)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        resultadosTxt.setEditable(false);
        resultadosTxt.setColumns(20);
        resultadosTxt.setRows(5);
        resultadosTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(resultadosTxt);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Usuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>                        

    private void campoSaldoActionPerformed(java.awt.event.ActionEvent evt) {                                           
    }                                          

   private void jugarActionPerformed(java.awt.event.ActionEvent evt) {                                      
        if (listaJugadores.isEmpty()) {
            resultadosTxt.setText("Primero debes crear al menos un jugador.");
            return;
        }

        int indexJugador = selectorJugador.getSelectedIndex();
        if (indexJugador < 0) {
            resultadosTxt.setText("Selecciona un jugador válido.");
            return;
        }

        Jugador jgActual = listaJugadores.get(indexJugador);

        if (campoApuesta.getText().trim().isEmpty()) {
            resultadosTxt.setText("Por favor ingresa un monto de apuesta.");
            return;
        }

        try {
            double apuesta = Double.parseDouble(campoApuesta.getText());
            String seleccion = selectorJuego.getSelectedItem().toString();
            String seleccionRuleta;
            int numero;
            Juego juego = null;

            switch (seleccion) {
                case "Ruleta":
                    seleccionRuleta = selectorRuleta.getSelectedItem().toString();
                    if (seleccionRuleta.equals("Par") || seleccionRuleta.equals("Impar")) {
                        juego = new Ruleta(seleccionRuleta.toLowerCase(), apuesta);
                    } else {
                        if (campoNumero.getText().trim().isEmpty()) {
                            resultadosTxt.setText("Ingresa el número para apostar en la Ruleta.");
                            return;
                        }
                        numero = Integer.parseInt(campoNumero.getText());
                        // AHORA FUNCIONA PERFECTAMENTE CON 'apuesta' COMO DOUBLE
                        juego = new Ruleta("numero", apuesta, numero);
                    }
                    break;

                case "Tragaperras":
                    juego = new Tragaperras(apuesta);
                    break;

                case "Dado":
                    juego = new Dado(apuesta);
                    break;
            }

            if (juego != null) {
                String resultado = juego.jugar(jgActual);
                resultadosTxt.setText("Jugador: " + jgActual.getNombre() + " | Saldo actual: $" + jgActual.getDinero() + "\n\n" + resultado);
            }
        } catch (NumberFormatException e) {
            resultadosTxt.setText("Error: Ingresa valores numéricos válidos en la apuesta/número.");
        }
    }                                     

    private void selectorJuegoActionPerformed(java.awt.event.ActionEvent evt) {                                               
        String juego = selectorJuego.getSelectedItem().toString();
        String seleccionRuleta = selectorRuleta.getSelectedItem().toString();

        if (juego.equals("Ruleta")) {
            jLabel6.setVisible(true);
            selectorRuleta.setVisible(true);

            if (seleccionRuleta.equals("Numero")) {
                jLabel7.setVisible(true);
                campoNumero.setVisible(true);
            } else {
                jLabel7.setVisible(false);
                campoNumero.setVisible(false);
            }
        } else {
            jLabel6.setVisible(false);
            selectorRuleta.setVisible(false);
            jLabel7.setVisible(false);
            campoNumero.setVisible(false);
        }
    }                                              

    private void crearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {                                             
        String nombre = campoNombre.getText().trim();
        String saldoStr = campoSaldo.getText().trim();

        if (nombre.isEmpty() || saldoStr.isEmpty()) {
            resultadosTxt.setText("Debes ingresar nombre y saldo para crear un jugador.");
            return;
        }

        try {
            double saldo = Double.parseDouble(saldoStr);
            Jugador nuevoJugador = new Jugador(nombre, saldo);
            
            listaJugadores.add(nuevoJugador);
            selectorJugador.addItem(nuevoJugador.getNombre());
            selectorJugador.setSelectedIndex(selectorJugador.getItemCount() - 1);

            campoNombre.setText("");
            campoSaldo.setText("");
            resultadosTxt.setText("Jugador creado con éxito:\n" +
                                 "Nombre: " + nuevoJugador.getNombre() + 
                                 "\nSaldo inicial: $" + nuevoJugador.getDinero());
        } catch (NumberFormatException e) {
            resultadosTxt.setText("Error: El saldo debe ser un valor numérico válido.");
        }
    }                                            

    private void estadisticasActionPerformed(java.awt.event.ActionEvent evt) {                                             
        if (listaJugadores.isEmpty()) {
            resultadosTxt.setText("No hay jugadores registrados.");
            return;
        }

        StringBuilder sb = new StringBuilder("--- JUGADORES REGISTRADOS ---\n");
        for (Jugador j : listaJugadores) {
            sb.append("• ").append(j.getNombre())
              .append(" | Saldo disponible: $").append(j.getDinero())
              .append("\n");
        }
        resultadosTxt.setText(sb.toString());
    }                                            

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new InterfazGrafica().setVisible(true));
    }

    // Variables declaration - do not modify                     
    private javax.swing.JPanel Usuario;
    private javax.swing.JTextField campoApuesta;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextField campoNumero;
    private javax.swing.JTextField campoSaldo;
    private javax.swing.JToggleButton crearUsuario;
    private javax.swing.JToggleButton estadisticas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelJugadorActivo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jugar;
    private javax.swing.JTextArea resultadosTxt;
    private javax.swing.JComboBox<String> selectorJuego;
    private javax.swing.JComboBox<String> selectorJugador;
    private javax.swing.JComboBox<String> selectorRuleta;
    // End of variables declaration                   
}