/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class Empresa_de_nomina {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
