/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class Gerente extends Empleado{
    private double salario;
    private double bonificacionAnual;

    public Gerente(double salario, double bonificacionAnual, String nombre, String id) {
        super(nombre, id);
        this.salario = salario;
        this.bonificacionAnual = bonificacionAnual;
    }

    @Override
    public double pagoMensual() {
        return salario+(bonificacionAnual/12);
    }
    
    
}
