/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class ProovedorExterno {
    private String nombre;
    private Factura factura;

    public ProovedorExterno(String nombre, Factura factura) {
        this.nombre = nombre;
        this.factura = factura;
    }
    
    public double Pago(){
        return factura.ConsultarValor();
    }
}
