/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class Factura {
    private String nombre;
    private double valor;

    public Factura(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }
    
    public double ConsultarValor(){
        return valor;
    }
    
}
