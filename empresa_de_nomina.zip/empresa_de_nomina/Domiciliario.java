/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class Domiciliario extends Empleado{
    private int pagoBase;
    private int pagoPorEntrega;
    private int entregasRealizadas;

    public Domiciliario(int pagoBase, int pagoPorEntrega, int entregasRealizadas, String nombre, String id) {
        super(nombre, id);
        this.pagoBase = pagoBase;
        this.pagoPorEntrega = pagoPorEntrega;
        this.entregasRealizadas = entregasRealizadas;
    }

    @Override
    public double pagoMensual() {
        return pagoBase+(pagoPorEntrega*entregasRealizadas);
    }
    
}
