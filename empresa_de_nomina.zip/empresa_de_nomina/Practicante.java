/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package github.com.lilliaenjoyer.programacioni.empresa_de_nomina;

/**
 *
 * @author samue
 */
public class Practicante extends Empleado{
    private int auxilioFijo;

    public Practicante(String nombre, String id, int auxilioFijo) {
        super(nombre, id);
        this.auxilioFijo = auxilioFijo;
    }


    @Override
    public double pagoMensual() {
        return auxilioFijo;
    }
    
    
}
